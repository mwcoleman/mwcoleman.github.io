### README.md
 
 
This repository contains my personal website. It uses Jekyll, and the theme is forked from Jekyll-Now. Posts are located in `\_posts`, and they are often (but not always) converted Jupyter notebooks (which are located in `\_notebooks`)
