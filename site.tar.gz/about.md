---
layout: page
title: About
permalink: /about/
published: true
---

Hi. My name's Matt and I live in Melbourne (Aus). I'm part electronic engineer, part data analyst, and part outdoors enthusiast.

### More Information

I'm a qualified Engineer who's worked across the health, telecommunications, and power industries. I'm currently studying A.I./data science at Monash University. I'm interested in machine learning, data science and software development; and generally enjoy building, testing, breaking and fixing things. Most of all I love to learn.

Feel free to get in touch through my linked.in page. Thanks for visiting!
