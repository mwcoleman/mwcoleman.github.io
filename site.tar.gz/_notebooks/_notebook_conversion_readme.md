New notebook files go in their own folder within _notebooks

when ready to convert to md, nav to _notebooks and "bash convert.sh folder/file" without .ipynb extension

This will nbconvert the ipynb to md, strip svg reference and replace with html for png, add yaml header, copy image files to _images/ an
